package com.anclab.pro

object NativeBridge {
    init { System.loadLibrary("anclab") }
    external fun nativeStart(outId: Int, inId: Int, gain: Float): Int   // 0 ok, 1 out fail, 2 in fail, 3 start fail
    external fun nativeCommand(cmd: Int, freqHz: Float)               // 1 calibrar, 2 activar ANC, 3 volver a monitor
    external fun nativeStop()
    external fun nativeEmergencyStop()
    external fun nativeSetGain(g: Float)
    external fun nativeStats(): DoubleArray                            // -1.0 == "No medida"
    external fun nativeSnapshot(out: FloatArray)
    external fun nativeSimulate(tonal: Boolean, pDelay: Int, sDelay: Int, mu: Float): Double
}
